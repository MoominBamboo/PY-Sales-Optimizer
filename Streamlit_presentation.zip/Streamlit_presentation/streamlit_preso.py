import streamlit as st 
#import seaborn as sns 
#import matplotlib.pyplot as plt
#import plotly.express as px
#import numpy as np 
#import pandas as pd 


#df = pd.read_csv("train.csv",index_col=0)

st.sidebar.title("PY-Sales-Optimizer")
pages = ["1. Data Description",
         "2. Data Exploration & Pre-processing",
         "3. RFM Segmentation",
         "4. Marketing Strategy"]
page = st.sidebar.radio("Table of contents", pages)

if page==pages[0]:
    st.title("1. Data Description")
    st.markdown("The underlying dataset consist of online transactions from several Pakistani e-commerce merchants. The transactions were conducted between July, 2016 and August, 2018.")
    st.markdown("The data is organized in 1.048.575 rows and 26 columns where each row relates to a single transaction. The table below summarizes the corresponding attributes and provides a short description:")
    st.image("figures/table1.jpg")

    st.markdown("The amounts of missing values per column are negligible (<0.03%). The following graphic provides a visualization of the situation:")
    st.image("figures/fig1.1.jpg")

    st.markdown("Additional attention must be paid to extreme values and outliers which can be observed for the numeric variables:")
    st.image("figures/fig1.2.jpg")

    #st.dataframe(df.head())

elif page==pages[1]:
    st.title("2. Data Exploration & Pre-processing")
    st.markdown("### 2.1 Transactions, orders & status")
    st.markdown("The 584.314 remaining transactions are resulting from 408.659 single orders. This result is based on the circumstance that 80% of orders only contain one transaction. However, this should not hide the fact that orders with up to 72 transactions exist:")
    st.image("figures/fig2.1.1.jpg")
    
    st.markdown("### 2.2 Price, discount amount & grand total")
    st.markdown("The calculated indicator is significantly correlated with the share of successful product sales as it increases the likelihood for completion and reduces the likelihood for cancellation of a transaction.")
    st.image("figures/fig2.2.1.jpg")
    
    st.markdown("### 2.3 Consumption categories")
    st.markdown("there are 14 specified and one Other category to which the ordered products are assigned to.")
    st.image("figures/fig2.3.1.jpg")
    
    #fig = plt.figure()
    #sns.countplot(x="Survived",data=df);
    #st.pyplot(fig)
    
    #hist_surv = px.histogram(df,x="Survived",color="Sex",barmode="group")
    #st.plotly_chart(hist_surv)

    
elif page==pages[2]:
    st.title("3. RFM segmentation")
    st.markdown("### 3.1 Introduction to RFM segmentation")
    st.markdown("The table below visualizes a potential result of a RFM segmentation and builds the background for the development of a baseline model in the next section:")
    st.image("figures/fig3.1.1.jpg")
    
    st.markdown("### 3.2 RFM scores & baseline model")
    st.markdown("Please be aware that customers with highest “Recency” must receive the lowest Recency-scores. These tables include 60.911 customers and build the basis for the analyses conducted in chapter 3.3.")
    st.image("figures/fig3.2.1a.jpg")
    st.image("figures/fig3.2.1b.jpg")
    
elif page==pages[3]:
    
    st.title("4. Marketing Strategy")
    st.markdown("We aim to uplift company’s sales by approaching customers with a tailor-made product offer. To be successful, it is crucial to approach the ***right customer*** with the ***right offer*** at the ***right point in time***.")
    st.markdown("### 4.1 The right customer")
    st.markdown("Let's look at customer segments that has the highest chance to respond positively to a campaign. The table below provides an overview fo the selected segments and the relevant KPIs:")
    st.image("figures/table4.1.jpg")
    
    st.markdown("### 4.2 The right offer")
    st.markdown("Most of the customers have a tendency to buy products from only 1 or 2 categories, except 'High-Potentials' customers. Hence we tailer the offer to the dominating product category in each group as below.")
    st.image("figures/fig4.2.1.jpg")

    st.markdown("Second part of the strategy relates to the discount amount we offer to our customers. As the effectiveness of discounts may vary considerably depending on the related product category.")
    st.markdown("In general, we expect higher the % of completed orders with a higher % discount offered. For a marketing campaign, we select 5% to 20% as the optimal discount rate as part of the strategy.")
    st.image("figures/fig4.2.2.jpg")

    st.markdown("### 4.3 The right time")
    st.markdown("It's important to launch the marketing campaign when customers are more likely to make a purchase, such as during holidays, seasonal-closings or 'Black-Friday-weeks'. We analysed partterns of purchase behaviour of the selected customer segemnts.")
    st.image("figures/fig4.3.jpg")
    st.markdown("Looking at the amount of transactions, we can see a repeating peak in November of each year. This is related to the “Black Friday”-week in Pakistan and offers a great opportunity for placing our campaign. Another strong increase can be identified end of March where Pakistan celebrates the national day.")
    


